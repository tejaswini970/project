/**
 * 
 */
package com.cg.service;

import java.util.List;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;


/**
 * @author CAPG
 *
 */
public interface IBookingInfoService {

	public String confirmBooking(BookingInformationBean bookingInformationBean, FlightInformationBean flightInformationBean) throws ARSException;

	public List<FlightInformationBean> viewFlights(String Source,String destination)throws ARSException;
	
	/*void displayBooking(BookingInformationBean bookingInformationBean)throws ARSException;

	void cancelBooking(BookingInformationBean bookingInformationBean,FlightInformationBean flightInformationBean)throws ARSException;
*/
}
