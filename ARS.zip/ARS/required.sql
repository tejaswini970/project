create table Users (username varchar2(20), password varchar2(20), role varchar2(10), mobile_no number);

create table Airport (AirportName varchar2(20), Abbreviation varchar2(5), Location varchar2(40));

create table FlightInformation (flightno varchar2(5), airline varchar2(10), dep_city varchar2(10), arr_city varchar2(10), dep_date date, arr_date date, dep_time varchar2(10), arr_time varchar2(10), FirstSeats number, FirstSeatFare number(7,2), BussSeats number, BussSeatsFare number(7,2));

create table BookingInformation ( Booking_id varchar2(5), cust_email varchar2(20), no_of_passengers number, class_type varchar2(10), total_fare number(7,2), seat_number number(3), CreditCard_info varchar2(10), src_city varchar2(10), dest_city varchar2(10));


insert into users values('Admin','Admin','Admin',9999999999);
insert into users values('executive','executive','executive',9999999999);