/**
 * 
 */
package com.cg.ars.dao;

import com.cg.ars.exception.ARSException;



/**
 * @author CAPG
 *
 */
public interface IUserDao {
	
	public boolean isValidUser(String userName,String password,String role) throws ARSException;

	
}
