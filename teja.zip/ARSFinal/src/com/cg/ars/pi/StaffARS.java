package com.cg.ars.pi;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.service.FlightInfoServiceImpl;
import com.cg.service.IFlightInfoService;
import com.cg.service.IUserService;
import com.cg.service.UserServiceImpl;

public class StaffARS {
	
	
	static Scanner ip = new Scanner(System.in);
	public static IUserService userService = new UserServiceImpl();
	public static IFlightInfoService flightService = new FlightInfoServiceImpl();

	
	/*******************************************************************************************************
	 * - Function Name : viewAllFlights() 
	 * - Return Type   : void 
	 * - Author        : ARS Team 
	 * - Creation Date : 14/12/2017
	 * - Description   : getting flight information
	 ********************************************************************************************************/

	public void viewAllFlights() {
		try {

			List<FlightInformationBean> list = flightService
					.viewAllFlightInformation();
			for (FlightInformationBean flightInformationBean : list) {

				System.out.println(flightInformationBean);
			}
		} catch (ARSException e) {
			System.err.println("Flight information error " + e.getMessage());
		}
	}

	
	
	/*******************************************************************************************************
	 * - Function Name : viewParticularFlight() 
	 * - Return Type   : String 
	 * - Author        : ARS Team
	 * - Creation Date : 14/12/2017 
	 * - Description   : getting particular flight information
	 ********************************************************************************************************/

	public String viewParticularFlight() {
		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		System.out.println("Enter Flight Number: ");
		String flightNumber = ip.nextLine();
		try {

			FlightInformationBean bean = flightService
					.viewParticularFlightInfo(flightNumber);

			System.out.println(bean);
			return bean.getFlightNumber();
		} catch (ARSException e) {
			System.err.println("Flight information error " + e.getMessage());
		}
		return null;
	}

	
	
	/*******************************************************************************************************
	 * - Function Name : addFlight()
	 * - Return Type   : void 
	 * - Author        : ARS Team 
	 * - Creation Date : 14/12/2017
	 * - Description   : adding flight information
	 ********************************************************************************************************/

	public void addFlight() {
		FlightInformationBean fbean = new FlightInformationBean();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		System.out.println("Enter Flight Number");
		fbean.setFlightNumber(ip.nextLine());
		System.out.println("Enter Flight Airline");
		fbean.setAirline(ip.nextLine());
		System.out.println("Enter Departure City");
		fbean.setDepartureCity(ip.nextLine());
		System.out.println("Enter Arrival City");
		fbean.setArrivalCity(ip.nextLine());
		System.out.println("Enter Departure Date in the format MM/dd/yyyy");
		String depdate = ip.nextLine();
		LocalDate departureDate = LocalDate.parse(depdate, formatter);
		fbean.setDepartureDate(departureDate);
		System.out.println("Enter Arrival Date in the format MM/dd/yyyy");
		String arrdate = ip.nextLine();
		LocalDate arrivalDate = LocalDate.parse(arrdate, formatter);
		fbean.setArrivalDate(arrivalDate);
		System.out.println("Enter Departure Time");
		fbean.setDepartureTime(ip.nextLine());
		System.out.println("Enter Arrival Time");
		fbean.setArrivalTime(ip.nextLine());
		System.out.println("Enter First Seats");
		fbean.setFirstClassSeats(ip.nextInt());
		System.out.println("Enter First Seat Fare");
		fbean.setFirstClassSeatFare(ip.nextDouble());
		System.out.println("Enter Business Seats");
		fbean.setBussinessClassSeats(ip.nextInt());
		System.out.println("Enter Business Seat Fare");
		fbean.setBussinessClassSeatsFare(ip.nextDouble());

		try {
			boolean isAdded = flightService.addFlight(fbean);
			if (isAdded) {
				System.out.println("Inserted successfully");
			} else {
				System.out.println("failed");
			}
		} catch (ARSException e) {

			e.printStackTrace();
		}
	}

	
	
	/*******************************************************************************************************
	 * - Function Name : updateFlight() 
	 * - Return Type   : void
	 * - Author        : ARS Team
	 * - Creation Date : 14/12/2017
	 * - Description   : updating flight information
	 ********************************************************************************************************/

	public void updateFlight() {
		
		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		String flightNo = viewParticularFlight();
		FlightInformationBean fbean = new FlightInformationBean();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

		
		fbean.setFlightNumber(flightNo);
		System.out.println("Enter Flight Airline");
		fbean.setAirline(ip.nextLine());
		System.out.println("Enter Departure City");
		fbean.setDepartureCity(ip.nextLine());
		System.out.println("Enter Arrival City");
		fbean.setArrivalCity(ip.nextLine());
		System.out.println("Enter Departure Date in the format MM/dd/yyyy");
		String depdate = ip.nextLine();
		LocalDate departureDate = LocalDate.parse(depdate, formatter);
		fbean.setDepartureDate(departureDate);
		System.out.println("Enter Arrival Date in the format MM/dd/yyyy");
		String arrdate = ip.nextLine();
		LocalDate arrivalDate = LocalDate.parse(arrdate, formatter);
		fbean.setArrivalDate(arrivalDate);
		System.out.println("Enter Departure Time");
		fbean.setDepartureTime(ip.nextLine());
		System.out.println("Enter Arrival Time");
		fbean.setArrivalTime(ip.nextLine());
		System.out.println("Enter First Seats");
		fbean.setFirstClassSeats(ip.nextInt());
		System.out.println("Enter First Seat Fare");
		fbean.setFirstClassSeatFare(ip.nextDouble());
		System.out.println("Enter Business Seats");
		fbean.setBussinessClassSeats(ip.nextInt());
		System.out.println("Enter Business Seat Fare");
		fbean.setBussinessClassSeatsFare(ip.nextDouble());
		try {
			FlightInformationBean bean = flightService
					.updateFlightInformation(fbean);
			System.out.println("updated");
			System.out.println(bean.getFlightNumber());
		} catch (Exception e) {
			System.err.println("not updated " + e.getMessage());
		}

	}

	
	
	/*******************************************************************************************************
	 * - Function Name : deleteFlight() 
	 * - Return Type   : void 
	 * - Author        : ARS Team
	 * - Creation Date : 14/12/2017 
	 * - Description   : deleting flight information
	 ********************************************************************************************************/

	public void deleteFlight() {
		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		System.out.println("Enter Flight Number : ");
		String FlightNo = ip.nextLine();

		try {
			boolean isDeleted = flightService.deleteFlight(FlightNo);

			if (isDeleted)
				System.out.println("Deleted successfully!");

		} catch (Exception e) {
			System.err.println("unable to delete " + e.getMessage());
		}

	}

	
	
	/*******************************************************************************************************
	 * - Function Name : overAllOccupancy() 
	 * - Return Type   : void  
	 * - Author        : ARS Team 
	 * - Creation Date : 14/12/2017 
	 * - Description   : gets overall occupancy information of flight from particular source to destination
	 ********************************************************************************************************/

	public void overAllOccupancy() {
		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		System.out.println("Enter Departure City");
		String sourceCity = ip.nextLine();
		System.out.println("Enter Arrival City");
		String destinationCity = ip.nextLine();

		try {
			HashMap<String, String> hmap = flightService.viewOverAllOccupancy(
					sourceCity, destinationCity);

			if (hmap == null) {
				System.out.println("No flights found");
			} else {
				System.out.println(hmap);
			}

		} catch (ARSException e) {

			System.err.println("unable to view overAllOccupancy "
					+ e.getMessage());
		}

	}

	
	
	/*******************************************************************************************************
	 * - Function Name : periodOccupancy() 
	 * - Return Type   : void  
	 * - Author        : ARS Team 
	 * - Creation Date : 14/12/2017 
	 * - Description   : gets period occupancy information of particular flight on particular date
	 ********************************************************************************************************/

	public void periodOccupancy() {
		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		System.out.println("Enter Flight Number: ");
		String FlightNo = ip.nextLine();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		System.out.println("Enter Departure Date in the format MM/dd/yyyy");
		String depdate = ip.nextLine();
		LocalDate departureDate = LocalDate.parse(depdate, formatter);

		System.out.println("Enter Arrival Date in the format MM/dd/yyyy");
		String arrdate = ip.nextLine();
		LocalDate arrivalDate = LocalDate.parse(arrdate, formatter);

		try {
			int occupancy = flightService.viewPeriodOccupancy(FlightNo,
					departureDate, arrivalDate);

			if (occupancy == 0) {
				System.out.println("No occupancy found");
			} else {
				System.out.println("Occupancy " + occupancy);
			}

		} catch (ARSException e) {

			System.err.println("unable to view overAllOccupancy "
					+ e.getMessage());
		}
	}

}
