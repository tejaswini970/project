package com.cg.ars.pi;


import java.util.List;
import java.util.Scanner;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.service.BookingInfoServiceImpl;
import com.cg.service.FlightInfoServiceImpl;
import com.cg.service.IBookingInfoService;
import com.cg.service.IFlightInfoService;

public class CustomerARS {

	static Scanner ip = new Scanner(System.in);
	
	public static void confirmBooking() {
		BookingInformationBean bean = new BookingInformationBean();
	    IBookingInfoService bookinginfoservice=new  BookingInfoServiceImpl();
	    IFlightInfoService flightInfoService= new FlightInfoServiceImpl(); 
	    FlightInformationBean fbean =null;
	    String flightNo=null;
	    
		
		System.out.println("Please enter source and destination to view flights");
		System.out.println("PLease enter source city");
		String sourceCity = ip.nextLine();
		System.out.println("PLease enter destination city");
		String destinationCity = ip.nextLine();
	  try {
		
		List<FlightInformationBean> list= bookinginfoservice.viewFlights(sourceCity, destinationCity);
		
		for (FlightInformationBean flightInformationBean : list) {

			System.out.println(flightInformationBean);
		}
		
		System.out.println("Enter flight number to book flight ");
		   flightNo = ip.nextLine();
		   
		  fbean=flightInfoService.viewParticularFlightInfo(flightNo);
	  
	  } 
	  
	  catch (ARSException e1) {

        System.out.println("No flights Found");
		e1.printStackTrace();
	}
	   
 		
		System.out.println("Please enter below details");

		System.out.println("Enter customer Email");
		bean.setCustomerEmail(ip.nextLine());
		System.out.println("Enter Number of passenger");
		int noOfPassenger = Integer.parseInt(ip.nextLine());
		bean.setNumberOfPassengers(noOfPassenger);
		System.out.println("Enter Class Type");
		bean.setClassType(ip.nextLine());
		System.out.println("Enter credit Card Information");
		bean.setCreditCardInformation(ip.nextLine());
		
		bean.setFlightNumber(flightNo);
		

		try {
			String bookingId =bookinginfoservice.confirmBooking(bean, fbean);
			
			//System.out.println("Booking id is"+bookingId);
			
			
			if (bookingId!=null) {
				System.out.println("Booked successfully");
				System.out.println("Booking id is"+bookingId);
				
			} else {
				System.out.println("failed");
			}
		} catch (ARSException e) {

			e.printStackTrace();
		}
	}
	
	public static void cancelBooking() {
		
		BookingInformationBean bean = new BookingInformationBean();
	    IBookingInfoService bookinginfoservice=new  BookingInfoServiceImpl();
	    IFlightInfoService flightInfoService= new FlightInfoServiceImpl(); 
	    
	    
	    
		System.out.println("Enter Booking Id");
		String bookingId=ip.nextLine();
		
		try {
			bean=bookinginfoservice.displayBooking(bookingId);
			FlightInformationBean fbean =flightInfoService.viewParticularFlightInfo(bean.getFlightNumber());
			System.out.println("Inside cmain cancel");
			System.out.println(fbean);
			bookinginfoservice.cancelBooking(bookingId);
			bookinginfoservice.updateSeats(fbean, bean);
			
		} catch (ARSException e) {
			
			e.printStackTrace();
		}
				
		}
	
	
	
	
	public static void displayBooking() {
		
		BookingInformationBean bean = new BookingInformationBean();
	    IBookingInfoService bookinginfoservice=new  BookingInfoServiceImpl();
	   // IFlightInfoService flightInfoService= new FlightInfoServiceImpl(); 
	    
	    
	    
		System.out.println("Enter Booking Id");
		String bookingId=ip.nextLine();
		
		try {
			bean=bookinginfoservice.displayBooking(bookingId);
			System.out.println("inside displaybooking()");
			System.out.println(bean);
		} catch (ARSException e) {
			System.out.println("Error inside dispalyBooking()");
			e.printStackTrace();
		}
		
		
	}
}
