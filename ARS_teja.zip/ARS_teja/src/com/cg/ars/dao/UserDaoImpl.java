package com.cg.ars.dao;

import com.cg.ars.bean.UserBean;
import com.cg.ars.exception.ARSException;

public class UserDaoImpl implements IUserDao{

	@Override
	public UserBean getAuthentication(UserBean userBean) throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserBean createUser(UserBean userBean) throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}

}
