package com.cg.service;

import java.util.List;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.dao.BookingInfoDaoImpl;
import com.cg.ars.dao.IBookingInfoDao;
import com.cg.ars.exception.ARSException;

public class BookingInfoServiceImpl implements IBookingInfoService{

	IBookingInfoDao bookingDao=new BookingInfoDaoImpl();


	@Override
	public String confirmBooking(BookingInformationBean bookingInformationBean,
			FlightInformationBean flightInformationBean) throws ARSException {
		
		return bookingDao.confirmBooking(bookingInformationBean, flightInformationBean);
	}


	@Override
	public List<FlightInformationBean> viewFlights(String Source,
			String destination) throws ARSException {
		
		return bookingDao.viewFlights(Source, destination);
	}


	@Override
	public boolean cancelBooking(String bookingId) throws ARSException {
		
		return bookingDao.cancelBooking(bookingId);
	}


	@Override
	public BookingInformationBean displayBooking(String bookingId)
			throws ARSException {
		
		return bookingDao.displayBooking(bookingId);
	}





	@Override
	public boolean updateSeats(FlightInformationBean flightInformationBean,
			BookingInformationBean bookingInformationBean) throws ARSException {
		
		return bookingDao.updateSeats(flightInformationBean, bookingInformationBean);
	}


	@Override
	public boolean updateBooking(String bookingId, String cust_email)
			throws ARSException {
		
		return bookingDao.updateBooking(bookingId, cust_email);
	}

}
