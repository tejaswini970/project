/**
 * 
 */
package com.cg.service;

import java.util.List;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;


/**
 * @author CAPG
 *
 */
public interface IFlightInfoService {

	public List<FlightInformationBean> viewAllFlightInformation()  throws ARSException;

	public FlightInformationBean viewParticularFlightInfo(String flightNumber)throws ARSException;
	
	public boolean addFlight(FlightInformationBean bean) throws ARSException;
}
