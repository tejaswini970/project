package com.cg.ars.pi;

import java.util.Scanner;

import com.cg.ars.exception.ARSException;
import com.cg.service.FlightInfoServiceImpl;
import com.cg.service.IFlightInfoService;
import com.cg.service.IUserService;
import com.cg.service.UserServiceImpl;

public class ARSMain {
	StaffARS staff = new StaffARS();
	CustomerARS customer = new CustomerARS();
	static Scanner ip = new Scanner(System.in);
	public static IUserService userService = new UserServiceImpl();
	public static IFlightInfoService flightService = new FlightInfoServiceImpl();

	/********************************************************************
	 * 
	 *Welcome page
	 *
	 * ******************************************************************/
	
	public static void main(String[] args) {
		Scanner ip = new Scanner(System.in);
		System.out.println("=====================================");
		System.out.println("WELCOME TO AIRLINE RESERVATION SYSTEM");
		System.out.println("SELECT THE USER TYPE TO LOGIN : ");
		System.out.println("1. CUSTOMER LOGIN");
		System.out.println("2. STAFF LOGIN");
		Byte choice = Byte.parseByte(ip.next());
		
		/********************************************************************
		 * 
		 * Customer 
		 *
		 * ******************************************************************/
		
		if (choice == 1) {
			System.out.println("Inside if");
			System.out.println("customer");
			CustomerARS.confirmBooking();

			
		} 
		
		/********************************************************************
		 * 
		 * Admin/executive
		 *
		 * ******************************************************************/
		
		else if(choice == 2){
			
			System.out.println("SELECT THE USER TYPE TO LOGIN : ");
			System.out.println("1. ADMIN LOGIN");
			System.out.println("2. EXECUTIVE LOGIN");
			Byte choice1 = Byte.parseByte(ip.next());
			
			/********************************************************************
			 * 
			 * Admin functionalities
			 *
			 * ******************************************************************/
			
			if (choice1 == 1) {

				ip.nextLine();
				System.out.println("Enter username");
				String username = ip.nextLine();
				System.out.println("Enter password");
				String password = ip.nextLine();
				boolean isValid = false;
				try {
					isValid = userService.isValidUser(username, password,
							"Admin");
				} catch (ARSException e) {
					System.out.println("Exception in admin login "
							+ e.getMessage());
				}
				if (isValid) {
					System.out.println("Welcome " + username);
					while (isValid) {
						System.out.println("1--Display Flight Details");
						System.out.println("2--Add Flight");
						System.out.println("3--Update Flight");
						System.out.println("4--delete Flight");
						System.out.println("5--ViewParticular flight");
						System.out.println("6--exit");

						int choice2 = ip.nextInt();

						switch (choice2) {

						case 1:
							StaffARS.viewAllFlights();
							break;
						case 2:
							StaffARS.addFlight();
							break;
						case 3:
							StaffARS.updateFlight();
							break;
						case 4:
							StaffARS.deleteFlight();
							break;
						case 5:
							StaffARS.viewParticularFlight();
							break;
						case 6:
							isValid = false;
							break;
						}

					}

				} else {
					System.out.println("Invalid user");
				}

			}

			/********************************************************************
			 * 
			 * executive functionalities
			 *
			 * ******************************************************************/
			
			else if (choice == 2) {
				ip.nextLine();
				System.out.println("Enter username");
				String username = ip.nextLine();
				System.out.println("Enter password");
				String password = ip.nextLine();
				boolean isValid = false;
				try {
					isValid = userService.isValidUser(username, password,
							"executive");
				} catch (ARSException e) {
					System.err.println("Exception in executive login "
							+ e.getMessage());
				}
				if (isValid) {
					System.out.println("Welcome " + username);
					while (isValid) {
						System.out.println("1--view period occupancy");
						System.out.println("2--view overall occupancy");
						System.out.println("3--Exit");
						int choice3 = ip.nextInt();
						switch (choice3) {
						case 1:
							StaffARS.periodOccupancy();
							break;
						case 2:
							StaffARS.overAllOccupancy();
							break;
						case 3:
							isValid = false;
							break;
						}
					}

				} else {
					System.out.println("Invalid user");
				}
			}

			ip.close();

		}

	}

}
