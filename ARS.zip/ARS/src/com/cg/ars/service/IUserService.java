package com.cg.ars.service;


import com.cg.ars.exception.ARSException;

public interface IUserService {
	public String validUser(String userName,String password,String role,String mobileNo) throws ARSException;
	
}
