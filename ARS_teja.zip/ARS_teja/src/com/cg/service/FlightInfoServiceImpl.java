package com.cg.service;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;

public class FlightInfoServiceImpl implements IFlightInfoService{

	@Override
	public FlightInformationBean getAirplaneInfo(
			FlightInformationBean flightInformationBean) throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FlightInformationBean fetchFlight(
			FlightInformationBean flightInformationBean) throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FlightInformationBean addFlight() throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FlightInformationBean deleteFlight(String flightNo)
			throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FlightInformationBean updateFlight(String flightNo)
			throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}

}
