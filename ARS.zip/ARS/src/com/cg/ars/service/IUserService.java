package com.cg.ars.service;

import com.cg.ars.bean.UserBean;
import com.cg.ars.exception.ARSException;

public interface IUserService {
	public boolean insertUser(UserBean userBean) throws ARSException;
	
}
