package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.ars.util.DBConnection;

public class FlightInfoDaoImpl implements IFlightInfoDao{

	@Override
	public List<FlightInformationBean> viewAllFlightInformation()
			throws ARSException {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<FlightInformationBean> list = new ArrayList<FlightInformationBean>();

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(IStaffQueryMapper.VIEW_FLIGHT_INFORMATION);


			resultSet = preparedStatement.executeQuery();
			
			while (resultSet.next()) {
				FlightInformationBean bean =new FlightInformationBean();
				
				bean.setFlightNumber(resultSet.getString("flightno"));
				bean.setAirline(resultSet.getString("airline"));
				bean.setDepartureCity(resultSet.getString("dep_city"));
				bean.setArrivalCity(resultSet.getString("arr_city"));
				bean.setDepartureDate(resultSet.getDate("dep_date").toLocalDate());
				bean.setArrivalDate(resultSet.getDate("arr_date").toLocalDate());
				bean.setDepartureTime(resultSet.getString("dep_time"));
				bean.setArrivalTime(resultSet.getString("arr_time"));
				bean.setFirstClassSeats(resultSet.getInt("FirstSeats"));
				bean.setFirstClassSeatFare(resultSet.getDouble("FirstSeatFare"));
				bean.setBussinessClassSeats(resultSet.getInt("BussSeats"));
				bean.setBussinessClassSeatsFare(resultSet.getDouble("BussSeatsFare"));
				
				list.add(bean);
			}
			
			

			// logger.info("Admin is authenticated.");

		} catch (Exception e) {
			throw new ARSException("No such user " + e.getMessage());
		}
		return list;
	}

	@Override
	public FlightInformationBean viewParticularFlightInfo(String flightNumber)
			throws ARSException {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		FlightInformationBean bean = new FlightInformationBean();

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(IStaffQueryMapper.VIEW_PARTICULAR_FLIGHT_INFORMATION);

			preparedStatement.setString(1, flightNumber);
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				
				
				bean.setFlightNumber(resultSet.getString("flightno"));
				bean.setAirline(resultSet.getString("airline"));
				bean.setDepartureCity(resultSet.getString("dep_city"));
				bean.setArrivalCity(resultSet.getString("arr_city"));
				bean.setDepartureDate(resultSet.getDate("dep_date").toLocalDate());
				bean.setArrivalDate(resultSet.getDate("arr_date").toLocalDate());
				bean.setDepartureTime(resultSet.getString("dep_time"));
				bean.setArrivalTime(resultSet.getString("arr_time"));
				bean.setFirstClassSeats(resultSet.getInt("FirstSeats"));
				bean.setFirstClassSeatFare(resultSet.getDouble("FirstSeatFare"));
				bean.setBussinessClassSeats(resultSet.getInt("BussSeats"));
				bean.setBussinessClassSeatsFare(resultSet.getDouble("BussSeatsFare"));
				
				return bean;
			}
			
			

			// logger.info("Admin is authenticated.");

		} catch (Exception e) {
			throw new ARSException("No such user " + e.getMessage());
		}
		return null;
	}

	@Override
	public boolean addFlight(FlightInformationBean bean) throws ARSException {
		PreparedStatement preparedStatement = null;
		
		
		boolean isInserted=false;

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(IStaffQueryMapper.ADD_FLIGHT);

			preparedStatement.setString(1, bean.getFlightNumber());
			preparedStatement.setString(2, bean.getAirline());
			preparedStatement.setString(3, bean.getDepartureCity());
			preparedStatement.setString(4, bean.getArrivalCity());
			preparedStatement.setDate(5, Date.valueOf(bean.getDepartureDate()));
			preparedStatement.setDate(6, Date.valueOf(bean.getArrivalDate()));
			preparedStatement.setString(7, bean.getDepartureTime());
			preparedStatement.setString(8, bean.getArrivalTime());
			preparedStatement.setInt(9, bean.getFirstClassSeats());
			preparedStatement.setDouble(10, bean.getFirstClassSeatFare());
			preparedStatement.setInt(11, bean.getBussinessClassSeats());
			preparedStatement.setDouble(12, bean.getBussinessClassSeatsFare());
			
			int inserted =preparedStatement.executeUpdate();
			if (inserted>0) {
				System.out.println("");
				isInserted=true;
			} 			

			// logger.info("Admin is authenticated.");

		} catch (Exception e) {
			throw new ARSException("No such user " + e.getMessage());
		}
		return isInserted;
	}
}



	

