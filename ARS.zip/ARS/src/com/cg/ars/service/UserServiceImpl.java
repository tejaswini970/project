package com.cg.ars.service;




import com.cg.ars.dao.IUserDAO;
import com.cg.ars.dao.UserDAOImpl;
import com.cg.ars.exception.ARSException;

public class UserServiceImpl implements IUserService {

	
	@Override
	public String validUser(String userName,String password,String role,String mobileNo) throws ARSException {
		IUserDAO userDAO = new UserDAOImpl() ;
		String user =userDAO.validuser(userName,password,role,mobileNo);
		return user;
	}
}