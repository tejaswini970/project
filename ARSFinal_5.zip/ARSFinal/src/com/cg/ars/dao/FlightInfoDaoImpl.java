package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.ars.util.DBConnection;

public class FlightInfoDaoImpl implements IFlightInfoDao{

	@Override
	public List<FlightInformationBean> viewAllFlightInformation()
			throws ARSException {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<FlightInformationBean> list = new ArrayList<FlightInformationBean>();

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(IStaffQueryMapper.VIEW_FLIGHT_INFORMATION);


			resultSet = preparedStatement.executeQuery();
			
			while (resultSet.next()) {
				FlightInformationBean bean =new FlightInformationBean();
				
				bean.setFlightNumber(resultSet.getString("flightno"));
				bean.setAirline(resultSet.getString("airline"));
				bean.setDepartureCity(resultSet.getString("dep_city"));
				bean.setArrivalCity(resultSet.getString("arr_city"));
				bean.setDepartureDate(resultSet.getDate("dep_date").toLocalDate());
				bean.setArrivalDate(resultSet.getDate("arr_date").toLocalDate());
				bean.setDepartureTime(resultSet.getString("dep_time"));
				bean.setArrivalTime(resultSet.getString("arr_time"));
				bean.setFirstClassSeats(resultSet.getInt("FirstSeats"));
				bean.setFirstClassSeatFare(resultSet.getDouble("FirstSeatFare"));
				bean.setBussinessClassSeats(resultSet.getInt("BussSeats"));
				bean.setBussinessClassSeatsFare(resultSet.getDouble("BussSeatsFare"));
				
				list.add(bean);
			}
			
			

			// logger.info("Admin is authenticated.");

		} catch (Exception e) {
			throw new ARSException("No flight found exception " + e.getMessage());
		}
		return list;
	}

	@Override
	public FlightInformationBean viewParticularFlightInfo(String flightNumber)
			throws ARSException {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		FlightInformationBean bean = new FlightInformationBean();

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(IStaffQueryMapper.VIEW_PARTICULAR_FLIGHT_INFORMATION);

			preparedStatement.setString(1, flightNumber);
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				
				
				bean.setFlightNumber(resultSet.getString("flightno"));
				bean.setAirline(resultSet.getString("airline"));
				bean.setDepartureCity(resultSet.getString("dep_city"));
				bean.setArrivalCity(resultSet.getString("arr_city"));
				bean.setDepartureDate(resultSet.getDate("dep_date").toLocalDate());
				bean.setArrivalDate(resultSet.getDate("arr_date").toLocalDate());
				bean.setDepartureTime(resultSet.getString("dep_time"));
				bean.setArrivalTime(resultSet.getString("arr_time"));
				bean.setFirstClassSeats(resultSet.getInt("FirstSeats"));
				bean.setFirstClassSeatFare(resultSet.getDouble("FirstSeatFare"));
				bean.setBussinessClassSeats(resultSet.getInt("BussSeats"));
				bean.setBussinessClassSeatsFare(resultSet.getDouble("BussSeatsFare"));
				
				return bean;
			}
			
			

			// logger.info("Admin is authenticated.");

		} catch (Exception e) {
			throw new ARSException("No particular flight found exception " + e.getMessage());
		}
		return null;
	}

	@Override
	public boolean addFlight(FlightInformationBean bean) throws ARSException {
		PreparedStatement preparedStatement = null;
		
		
		boolean isInserted=false;

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(IStaffQueryMapper.ADD_FLIGHT);

			preparedStatement.setString(1, bean.getFlightNumber());
			preparedStatement.setString(2, bean.getAirline());
			preparedStatement.setString(3, bean.getDepartureCity());
			preparedStatement.setString(4, bean.getArrivalCity());
			preparedStatement.setDate(5, Date.valueOf(bean.getDepartureDate()));
			preparedStatement.setDate(6, Date.valueOf(bean.getArrivalDate()));
			preparedStatement.setString(7, bean.getDepartureTime());
			preparedStatement.setString(8, bean.getArrivalTime());
			preparedStatement.setInt(9, bean.getFirstClassSeats());
			preparedStatement.setDouble(10, bean.getFirstClassSeatFare());
			preparedStatement.setInt(11, bean.getBussinessClassSeats());
			preparedStatement.setDouble(12, bean.getBussinessClassSeatsFare());
			
			int inserted =preparedStatement.executeUpdate();
			if (inserted>0) {
				System.out.println("");
				isInserted=true;
			} 			

			// logger.info("Admin is authenticated.");

		} catch (Exception e) {
			throw new ARSException("Flight addition failed " + e.getMessage());
		}
		return isInserted;
	}

	@Override
	public FlightInformationBean updateFlightInformation(FlightInformationBean bean)
			throws ARSException {
		PreparedStatement preparedStatement = null;
		
		
		try {
			Connection connection = DBConnection.getInstance().getConnection();

		preparedStatement = connection
				.prepareStatement(IStaffQueryMapper.UPDATE_FLIGHT_INFORMATION);
	
		
		preparedStatement.setString(1, bean.getAirline());
		preparedStatement.setString(2, bean.getDepartureCity());
		preparedStatement.setString(3, bean.getArrivalCity());
		preparedStatement.setDate(4, Date.valueOf(bean.getDepartureDate()));
		preparedStatement.setDate(5, Date.valueOf(bean.getArrivalDate()));
		preparedStatement.setString(6, bean.getDepartureTime());
		preparedStatement.setString(7, bean.getArrivalTime());
		preparedStatement.setInt(8, bean.getFirstClassSeats());
		preparedStatement.setDouble(9, bean.getFirstClassSeatFare());
		preparedStatement.setInt(10, bean.getBussinessClassSeats());
		preparedStatement.setDouble(11, bean.getBussinessClassSeatsFare());
		preparedStatement.setString(12, bean.getFlightNumber());
		
		int isUpdated =  preparedStatement.executeUpdate();
		
		
		if(isUpdated>0)
		{
			return bean;
		}
		
		

	} catch (Exception e) {
		throw new ARSException("Flight updation failed " + e.getMessage());
	}

		return null;
	}

	@Override
	public boolean deleteFlight(String FlightNo)throws ARSException {
		
      PreparedStatement preparedStatement = null;
		
      int records=0;
		boolean isDeleted=false;

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(IStaffQueryMapper.DELETE_FLIGHT_INFORMATION);
			
          preparedStatement.setString(1, FlightNo);
			
			records=preparedStatement.executeUpdate();
			
			if(records>0)
				isDeleted=true;
			
			
		}catch(Exception e)
		{
			throw new ARSException("deletion failed " + e.getMessage());
		}
		return isDeleted;
	}

	
	@Override
	public HashMap<String, String> viewOverAllOccupancy(String sourceCity,
			String destinationCity) throws ARSException {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		HashMap<String, String> map = new HashMap<String, String>();

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(IStaffQueryMapper.VIEW_OVER_ALL_OCCUPANCY);
			preparedStatement.setString(1, sourceCity);
			preparedStatement.setString(2, destinationCity);

			resultSet = preparedStatement.executeQuery();
			
			while (resultSet.next()) {
				String flightno=resultSet.getString("flightno");
				String airline = resultSet.getString("airline");
				int occupancy = resultSet.getInt("occupancy");
				
				map.put(flightno, airline+" "+occupancy);
			}
			if (map.isEmpty()) {
				return null;
			} else {
				return map;
			}
			

			// logger.info("Admin is authenticated.");

		} catch (Exception e) {
			throw new ARSException("viewOverAllOccupancy failed in dao " + e.getMessage());
		}
	}

	
	@Override
	public int viewPeriodOccupancy(String flightNumber,
			LocalDate fromDate, LocalDate toDate) throws ARSException {
		
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int occupancy=0;

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(IStaffQueryMapper.VIEW_PERIOD_OCCUPANCY);
			preparedStatement.setString(1, flightNumber);
			preparedStatement.setDate(2, Date.valueOf(fromDate));
			//preparedStatement.setDate(3, Date.valueOf(toDate));

			resultSet = preparedStatement.executeQuery();
			
			if (resultSet.next()) {
				occupancy = resultSet.getInt("occupancy");
				return occupancy;
			}
		
			

			// logger.info("Admin is authenticated.");

		} catch (Exception e) {
			throw new ARSException("viewPeriodOccupancy failed in dao " + e.getMessage());
		}
		return occupancy;
	}

	
	
}



	

