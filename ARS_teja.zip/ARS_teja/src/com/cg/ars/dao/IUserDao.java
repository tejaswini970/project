/**
 * 
 */
package com.cg.ars.dao;

import com.cg.ars.bean.UserBean;
import com.cg.ars.exception.ARSException;



/**
 * @author CAPG
 *
 */
public interface IUserDao {
	public UserBean getAuthentication(UserBean userBean) throws ARSException;

	public UserBean createUser(UserBean userBean) throws ARSException;
}
