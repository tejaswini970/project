package com.cg.ars.dao;

public interface QueryMapper {
	public static final String VALID_USER = "SELECT role FROM users WHERE (username=? and password=? and role=? and mobile_no=? )";
	
}
