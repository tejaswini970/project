package com.cg.service;

import com.cg.ars.dao.IUserDao;
import com.cg.ars.dao.UserDaoImpl;
import com.cg.ars.exception.ARSException;

public class UserServiceImpl implements IUserService {

	IUserDao userDao = new UserDaoImpl();

	@Override
	public boolean isValidUser(String userName, String password, String role)
			throws ARSException {
		return userDao.isValidUser(userName, password, role);
	}

}
