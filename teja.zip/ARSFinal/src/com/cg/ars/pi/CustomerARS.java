package com.cg.ars.pi;

import java.util.List;
import java.util.Scanner;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.service.BookingInfoServiceImpl;
import com.cg.service.FlightInfoServiceImpl;
import com.cg.service.IBookingInfoService;
import com.cg.service.IFlightInfoService;




public class CustomerARS {

	static Scanner ip = new Scanner(System.in);
	
	/*******************************************************************************************************
	 * - Function Name : confirmBooking() 
	 * - Return Type   : void 
	 * - Author        : ARS Team 
	 * - Creation Date : 14/12/2017 
	 * - Description   : Booking A Ticket
	 ********************************************************************************************************/

	public void confirmBooking() {
		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		BookingInformationBean bean = new BookingInformationBean();
		IBookingInfoService bookinginfoservice = new BookingInfoServiceImpl();
		IFlightInfoService flightInfoService = new FlightInfoServiceImpl();
		FlightInformationBean fbean = null;
		String flightNo = null;

		System.out
				.println("Please enter source and destination to view flights");
		System.out.println("PLease enter source city");
		String sourceCity = ip.nextLine();
		System.out.println("PLease enter destination city");
		String destinationCity = ip.nextLine();
		
		
		
		try {

			List<FlightInformationBean> list = bookinginfoservice.viewFlights(
					sourceCity, destinationCity);

			for (FlightInformationBean flightInformationBean : list) {

				System.out.println(flightInformationBean);
			}

			System.out.println("Enter flight number to book flight ");
			flightNo = ip.nextLine();

			fbean = flightInfoService.viewParticularFlightInfo(flightNo);

		}

		catch (ARSException e1) {

			System.out.println("No flights Found");
			e1.printStackTrace();
		}

		System.out.println("Please enter below details");

		System.out.println("Enter customer Email");
		bean.setCustomerEmail(ip.nextLine());
		System.out.println("Enter Number of passenger");
		int noOfPassenger = Integer.parseInt(ip.nextLine());
		bean.setNumberOfPassengers(noOfPassenger);
		System.out.println("Enter Class Type");
		bean.setClassType(ip.nextLine());
		System.out.println("Enter credit Card Information");
		bean.setCreditCardInformation(ip.nextLine());

		bean.setFlightNumber(flightNo);
		String bookingId=null;
		try {
			//boolean isValid = bookinginfoservice.validateCustomer(bean);
			
				bookingId = bookinginfoservice.confirmBooking(bean, fbean);
			
			

			

			if (bookingId != null) {
				System.out.println("\nBooked successfully");
				System.out.println("Booking id is  " + bookingId);

			} else {
				System.out.println("failed");
			}
		} catch (ARSException e) {

			e.printStackTrace();
		}
	}

	
	
	/*******************************************************************************************************
	 * - Function Name : cancelBooking() 
	 * - Return Type   : void 
	 * - Author        : ARS Team 
	 * - Creation Date : 14/12/2017 
	 * - Description   : Cancel Booking
	 ********************************************************************************************************/
	
	public void cancelBooking() {

		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		BookingInformationBean bean = new BookingInformationBean();
		IBookingInfoService bookinginfoservice = new BookingInfoServiceImpl();
		IFlightInfoService flightInfoService = new FlightInfoServiceImpl();

		System.out.println("Enter Booking Id");
		String bookingId = ip.nextLine();

		try {
			bean = bookinginfoservice.displayBooking(bookingId);
			FlightInformationBean fbean = flightInfoService
					.viewParticularFlightInfo(bean.getFlightNumber());
		
			System.out.println(fbean);
			bookinginfoservice.cancelBooking(bookingId);
			bookinginfoservice.updateSeats(fbean, bean);

		} catch (ARSException e) {

			e.printStackTrace();
		}

	}
	
	
	
	/*******************************************************************************************************
	 * - Function Name : displayBooking() 
	 * - Return Type   : void 
	 * - Author        : ARS Team 
	 * - Creation Date : 14/12/2017 
	 * - Description   : Displays Flight information
	 ********************************************************************************************************/
	public void displayBooking() {

		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		BookingInformationBean bean = new BookingInformationBean();
		IBookingInfoService bookinginfoservice = new BookingInfoServiceImpl();
		// IFlightInfoService flightInfoService= new FlightInfoServiceImpl();

		System.out.println("Enter Booking Id");
		String bookingId = ip.nextLine();

		try {
			bean = bookinginfoservice.displayBooking(bookingId);
			
			System.out.println(bean);
		} catch (ARSException e) {
			System.out.println("Error inside dispalyBooking()");
			e.printStackTrace();
		}

	}

	
	
	/*******************************************************************************************************
	 * - Function Name : updateBooking() 
	 * - Return Type   : void 
	 * - Author        : ARS Team 
	 * - Creation Date : 14/12/2017 
	 * - Description   : Updates Flight information
	 ********************************************************************************************************/
	public void updateBooking() {

		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		IBookingInfoService bookinginfoservice = new BookingInfoServiceImpl();

		System.out.println("Enter Booking Id");
		String bookingId = ip.nextLine();

		try {
			BookingInformationBean bean = bookinginfoservice
					.displayBooking(bookingId);
			System.out.println(bean);
			System.out.println("Enter new email id");
			String email = ip.nextLine();

			bookinginfoservice.updateBooking(bookingId, email);

		} catch (ARSException e) {

			e.printStackTrace();
		}

	}
}
