/**
 * 
 */
package com.cg.ars.dao;

import java.util.List;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;


/**
 * @author CAPG
 *
 */
public interface IBookingInfoDao {

	public String confirmBooking(BookingInformationBean bookingInformationBean, FlightInformationBean flightInformationBean) throws ARSException;

	public BookingInformationBean displayBooking(String bookingId) throws ARSException;

	public boolean cancelBooking(String bookingId) throws ARSException;
	
	public boolean updateBooking(String bookingId,String cust_email) throws ARSException;

	public List<FlightInformationBean> viewFlights(String Source,String destination)throws ARSException;
	
   public boolean updateSeats(FlightInformationBean flightInformationBean,BookingInformationBean bookingInformationBean)throws ARSException;
}
