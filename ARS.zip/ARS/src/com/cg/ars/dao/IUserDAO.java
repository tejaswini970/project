package com.cg.ars.dao;

import com.cg.ars.exception.ARSException;


public interface IUserDAO {
	public String validuser(String userName,String password,String role,String mobileNo) throws ARSException;
	
}
