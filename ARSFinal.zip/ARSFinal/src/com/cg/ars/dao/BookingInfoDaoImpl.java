package com.cg.ars.dao;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;

public class BookingInfoDaoImpl implements IBookingInfoDao {

	@Override
	public BookingInformationBean confirmBooking(
			BookingInformationBean bookingInformationBean,
			FlightInformationBean flightInformationBean) throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void displayBooking(BookingInformationBean bookingInformationBean)
			throws ARSException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cancelBooking(BookingInformationBean bookingInformationBean,
			FlightInformationBean flightInformationBean) throws ARSException {
		// TODO Auto-generated method stub
		
	}

}
