package com.cg.ars.service;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ars.bean.UserBean;
import com.cg.ars.dao.IUserDAO;
import com.cg.ars.dao.UserDAOImpl;
import com.cg.ars.exception.ARSException;

public class UserServiceImpl implements IUserService {

	@Override
	public boolean insertUser(UserBean userBean) throws ARSException {
	
		boolean isItInserted = false;
		
		IUserDAO userDAO = new UserDAOImpl() ;
			isItInserted = userDAO.insertuser(userBean);
		return isItInserted;
		
	}

	public boolean isValidUserName(String userName) throws ARSException {
       
		boolean isValid = false;
		
		String pattern ="[A-Z]{1}[A-Za-z]{1,19}";
		
		Pattern ptn = Pattern.compile(pattern);
		Matcher matcher = ptn.matcher(userName);
		isValid = matcher.matches();
		
		if(!isValid){
			throw new ARSException("Invalid name");
		}
		
		return isValid;
	}

	public boolean isValidPassword(String password) throws ARSException {
		
		boolean isValid = false;
        String pattern =".{6,}";
		
		Pattern ptn = Pattern.compile(pattern);
		Matcher matcher = ptn.matcher(password);
		isValid = matcher.matches();
		
		if(!isValid){
			throw new ARSException("Must contain at least 6 or more characters");
		}
		
		return isValid;
	}


	public boolean isValidRole(String role) throws ARSException {
		boolean isValid = false;
        String pattern ="[A-Za-z0-9]{1,19}";
		
		Pattern ptn = Pattern.compile(pattern);
		Matcher matcher = ptn.matcher(role);
		isValid = matcher.matches();
		
		if(!isValid){
			throw new ARSException("Invalid role");
		}
		
		return isValid;
	}

	public boolean isValidmobileNo(String mobileNo) throws ARSException {
		boolean isValid = false;
		
		String pattern ="[\\d]{10}";
		
		Pattern ptn = Pattern.compile(pattern);
		Matcher matcher = ptn.matcher(mobileNo);
		isValid = matcher.matches();
		
		if(!isValid){
			throw new ARSException("Mobile No should contain 10 digits");
		}
		
		return isValid;
	}

}
