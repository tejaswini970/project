package com.cg.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.dao.FlightInfoDaoImpl;
import com.cg.ars.dao.IFlightInfoDao;
import com.cg.ars.exception.ARSException;

public class FlightInfoServiceImpl implements IFlightInfoService{
	
	IFlightInfoDao fdao = new FlightInfoDaoImpl();
	

	/**
	 * 
	 */
	
	
	@Override
	public List<FlightInformationBean> viewAllFlightInformation()
			throws ARSException {
		
		return fdao.viewAllFlightInformation();
	}

	@Override
	public FlightInformationBean viewParticularFlightInfo(String flightNumber)
			throws ARSException {
		
		return fdao.viewParticularFlightInfo(flightNumber);
	}

	@Override
	public boolean addFlight(FlightInformationBean bean) throws ARSException {
		
		return fdao.addFlight(bean);
	}

	
	
	@Override
	public boolean deleteFlight(String FlightNo) throws ARSException{
		
		return fdao.deleteFlight(FlightNo);
	}

	@Override
	public FlightInformationBean updateFlightInformation(
			FlightInformationBean flightInfoBean) throws ARSException {
		
		return fdao.updateFlightInformation(flightInfoBean);
	}

	@Override
	public HashMap<String, String> viewOverAllOccupancy(String sourceCity,
			String destinationCity) throws ARSException {
		
		return fdao.viewOverAllOccupancy(sourceCity, destinationCity);
	}

	@Override
	public int viewPeriodOccupancy(String flightNumber, LocalDate fromDate,
			LocalDate toDate) throws ARSException {
		// TODO Auto-generated method stub
		return fdao.viewPeriodOccupancy(flightNumber, fromDate, toDate);
	}

	
	@Override
	public boolean validateFlightDetails(FlightInformationBean bean)
	throws ARSException {
		
	List<String> validationErrors = new ArrayList<String>();

	//Validating FlightNumber
	if(!(isValidFlightNumber(bean.getFlightNumber()))) {
	validationErrors.add("\nInvalid sourceCity ! \n");
	}
	//Validating Airline
	if(!(isValidAirline(bean.getAirline()))){
	validationErrors.add("\n Invalid destinationCity! \n");
	}
	//Validating DepartureCity
	if(!(isValidDepartureCity(bean.getDepartureCity()))){
	validationErrors.add("\n Invalid Email Id \n");
	}
	//Validating ArrivalCity
	if(!(isValidArrivalCity(bean.getArrivalCity()))){
	validationErrors.add("\nInvalid Credit Card Info\n" );
	}
	//Validating DepartureTime
	if(!(isValidDepartureTime(bean.getDepartureTime()))){
	validationErrors.add("\nNumber of passenger should be  0 to 9\n" );
	}
	//Validating ArrivalTime
	if(!(isValidArrivalTime(bean.getArrivalTime()))){
	validationErrors.add("\nNumber of passenger should be  0 to 9\n" );
	}
	//Validating FirstClassSeats
	if(!(isValidFirstClassSeats(bean.getFirstClassSeats()))){
	validationErrors.add("\nNumber of passenger should be  0 to 9\n" );
	}
	//Validating FirstClassSeatFare
	if(!(isValidFirstClassSeatFare(bean.getFirstClassSeatFare()))){
	validationErrors.add("\nNumber of passenger should be  0 to 9\n" );
	}
	//Validating BussinessClassSeats
	if(!(isValidBussinessClassSeats(bean.getBussinessClassSeats()))){
	validationErrors.add("\nNumber of passenger should be  0 to 9\n" );
	}
	//Validating BussinessClassSeatsFare
	if(!(isValidBussinessClassSeatsFare(bean.getBussinessClassSeatsFare()))){
	validationErrors.add("\nNumber of passenger should be  0 to 9\n" );
	}
	 
	if(!validationErrors.isEmpty())
	{
	return false;
	}
	 
	return true;
	}


	private boolean isValidBussinessClassSeatsFare(
	double bussinessClassSeatsFare) {
	 
	return bussinessClassSeatsFare>0;
	}

	private boolean isValidBussinessClassSeats(int bussinessClassSeats) {
	 
	return bussinessClassSeats>0;
	}

	private boolean isValidFirstClassSeatFare(double firstClassSeatFare) {
	 
	return firstClassSeatFare>0;
	}

	private boolean isValidFirstClassSeats(int firstClassSeats) {
	 
	return firstClassSeats>0;
	}

	private boolean isValidArrivalTime(String arrivalTime) {
	 
	return arrivalTime!=null;
	}

	private boolean isValidDepartureTime(String departureTime) {
	 
	return departureTime!=null;
	}

	public boolean isValidArrivalCity(String arrivalCity)throws ARSException {
	boolean isValid = false;

	String pattern = "[a-zA-Z]{4,20}";

	Pattern ptn = Pattern.compile(pattern);

	Matcher matcher = ptn.matcher(arrivalCity);
	isValid = matcher.matches();

	 
	return isValid;
	}

	public boolean isValidDepartureCity(String departureCity) throws ARSException {
	boolean isValid = false;

	String pattern = "[a-zA-Z]{4,20}";

	Pattern ptn = Pattern.compile(pattern);

	Matcher matcher = ptn.matcher(departureCity);
	isValid = matcher.matches();

	 
	return isValid;
	}

	public boolean isValidAirline(String airline) throws ARSException{
	boolean isValid = false;

	String pattern = "[a-zA-Z]{4,20}";

	Pattern ptn = Pattern.compile(pattern);

	Matcher matcher = ptn.matcher(airline);
	isValid = matcher.matches();

	 
	return isValid;
	}

	public boolean isValidFlightNumber(String flightnumber) throws ARSException {

	boolean isValid = false;

	String pattern = "[\\d]{1,5}";

	Pattern ptn = Pattern.compile(pattern);

	Matcher matcher = ptn.matcher(flightnumber);
	isValid = matcher.matches();

	 
	return isValid;

	}
	

}
