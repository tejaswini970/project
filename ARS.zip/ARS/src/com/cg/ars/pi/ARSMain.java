package com.cg.ars.pi;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ars.bean.UserBean;
import com.cg.ars.exception.ARSException;
import com.cg.ars.service.UserServiceImpl;

public class ARSMain {
	
	private static Logger logger=Logger.getRootLogger();
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		boolean isInProcess = true;
		boolean isValid = false;
		byte choice = 0;
		
		String userName = null;
		String password = null;
		String role = null;
		String mobileNo = null;
		
		UserServiceImpl userService = new UserServiceImpl();

		UserBean userBean = null;

		Scanner scan = new Scanner(System.in);
		while (isInProcess) {
			System.out.println("1. Insert User.");

			choice = Byte.parseByte(scan.nextLine());
			
			switch (choice){
			case 1:
				isValid = false;

				while(!isValid){

					try{
						System.out.println("Enter User Name: ");
						userName= scan.nextLine();
						
						isValid = userService.isValidUserName(userName);
						
					}catch(ARSException mpe){
						logger.error("Invalid name: " +userName);
						System.err.println("Invalid name: " +userName+" First letter should be capital");
						isValid = false;
					}
				}
				isValid = false;
				
				while(!isValid){
					try{
						System.out.println("Enter Password: ");
						password= scan.nextLine();
						
						isValid = userService.isValidPassword(password);
						
					}catch(ARSException ars){
						logger.error("Invalid Password: " +password);
						System.err.println("Invalid Password: " +password+" Must contain 6 or more characters");
						isValid = false;
					}
				}
				isValid = false;
				
				while(!isValid){
					try{
						System.out.println("Enter Role: ");
						role= scan.nextLine();
						
						isValid = userService.isValidRole(role);
						
					}catch(ARSException mpe){
						logger.error("Invalid Role.: " +role);
						System.err.println("Invalid Role.: " +role);
						isValid = false;
					}
				}
				
				isValid = false;
				
				while(!isValid){
					try{
						System.out.println("Enter Mobile Number: ");
						mobileNo= scan.nextLine();
						
						isValid = userService.isValidmobileNo(mobileNo);
						
					}catch(Exception e){
						logger.error("Invalid Mobile Number: " +mobileNo);
						System.out.println("Invalid Mobile Number: " +mobileNo+" Must contain 10 digits");
						isValid = false;
					}
				}
				
				userBean = new UserBean(userName, password, role, mobileNo);
				try{
					userService.insertUser(userBean);
				}catch(ARSException e){
					logger.error(e.getMessage());
				}
			
			break;
			}
			
		}
		scan.close();
	}

}
