package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.ars.util.DBConnection;

public class BookingInfoDaoImpl implements IBookingInfoDao {
	

	static Logger logger=Logger.getRootLogger();
	public  BookingInfoDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	//------------------------ 1.Airline Book --------------------------
		/*******************************************************************************************************
					 - Function Name	:	confirmBooking()
					 - Input Parameters	:   bookingInformation,flightInformation
					 - Return Type		:	String
					 - Throws		    :   ARSException
					 - Author		    :   ARS Team
					 - Creation Date	:	16/12/2017
					 - Description		:	booking tickets
	 ********************************************************************************************************/
	
	@Override
	public String confirmBooking(BookingInformationBean bookingInformationBean,
			FlightInformationBean flightInformationBean) throws ARSException {
		PreparedStatement preparedStatement = null;
		//PreparedStatement preparedStatement1 = null;
		PreparedStatement preparedStatement2 = null;

		ResultSet resultSet = null;
		String bookingId = null;
		String seats = "";
		double totalAmount = 0;
		int no_of_passengers = 0;

		no_of_passengers = bookingInformationBean.getNumberOfPassengers();

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			
			String classtype = bookingInformationBean.getClassType();

			/*******************************************************************************************************
			 * - Author : ARS Team - Creation Date : 14/12/2017 - Description :
			 ********************************************************************************************************/

			if ("firstclass".equalsIgnoreCase(classtype)) {
				PreparedStatement pst = null;
				pst = connection
						.prepareStatement(ICutomerQueryMapper.FIRST_CLASS_SEQUENCE);

				int no_of_seats = flightInformationBean.getFirstClassSeats();
				if (no_of_seats < no_of_passengers || no_of_seats == 0) {
					throw new ARSException("No first class seats available");
				}
				PreparedStatement pst1 = null;
				pst1 = connection
						.prepareStatement(ICutomerQueryMapper.REDUCE_FIRST_SEATS);
				pst1.setString(1,
						flightInformationBean.getFlightNumber());
				int count = 0;

				for (int i = 1; i <= no_of_passengers; i++) {
					resultSet = pst.executeQuery();

					pst1.executeUpdate();

					while (resultSet.next()) {
						if (count == 0)
							seats = String.valueOf(resultSet.getLong(1));
						if (count != 0)
							seats = seats + " , "
									+ String.valueOf(resultSet.getLong(1));
						count++;
					}

				}

				totalAmount = bookingInformationBean.getNumberOfPassengers()
						* flightInformationBean.getFirstClassSeatFare();

			}
			
			/*******************************************************************************************************
			 * - Author : ARS Team - Creation Date : 14/12/2017 - Description :
			 ********************************************************************************************************/

			else if ("bussclass".equalsIgnoreCase(classtype))

			{
				PreparedStatement pst3 = null;
				pst3 = connection
						.prepareStatement(ICutomerQueryMapper.BUSINESS_CLASS_SEQUENCE);

				int no_of_seats = flightInformationBean
						.getBussinessClassSeats();
				if (no_of_seats < no_of_passengers || no_of_seats == 0) {
					throw new ARSException("No bussiness class seats available");
				}
				PreparedStatement pst4 = null;
				pst4 = connection
						.prepareStatement(ICutomerQueryMapper.REDUCE_BUSS_SEATS);
				pst4.setString(1,
						flightInformationBean.getFlightNumber());

				int count = 0;
				for (int i = 1; i <= no_of_passengers; i++) {

					resultSet = pst3.executeQuery();
					pst4.executeUpdate();

					while (resultSet.next()) {
						if (count == 0)
							seats = String.valueOf(resultSet.getLong(1));
						if (count != 0)
							seats = seats + " , "
									+ String.valueOf(resultSet.getLong(1));
						count++;
					}

				}
				totalAmount = bookingInformationBean.getNumberOfPassengers()
						* flightInformationBean.getBussinessClassSeatsFare();

			}

			/*******************************************************************************************************
			 * - Author : ARS Team - Creation Date : 14/12/2017 - Description :
			 ********************************************************************************************************/
			
			try {
				preparedStatement2 = connection
						.prepareStatement(ICutomerQueryMapper.BOOKING_ID_SEQUENCE);

				resultSet = preparedStatement2.executeQuery();

				while (resultSet.next()) {
					bookingId = String.valueOf(resultSet.getLong(1));
				}
			} catch (Exception e) {
				System.out.println("booking id error");
				e.printStackTrace();
			}

			
			
			preparedStatement = connection
					.prepareStatement(ICutomerQueryMapper.CONFIRM_BOOKING);

			preparedStatement.setString(1, bookingId);
			preparedStatement.setString(2,
					bookingInformationBean.getCustomerEmail());
			preparedStatement.setInt(3,
					bookingInformationBean.getNumberOfPassengers());
			preparedStatement.setString(4,
					bookingInformationBean.getClassType());
			preparedStatement.setDouble(5, totalAmount);
			preparedStatement.setString(6, seats);

			preparedStatement.setString(7,
					bookingInformationBean.getCreditCardInformation());
			preparedStatement.setString(8,
					flightInformationBean.getDepartureCity());
			preparedStatement.setString(9,
					flightInformationBean.getArrivalCity());
			preparedStatement.setString(10,
					bookingInformationBean.getFlightNumber());
			//resultSet = preparedStatement.executeQuery();
			int inserted = preparedStatement.executeUpdate();

			if (inserted > 0) {
				
				

				if ("firstclass".equalsIgnoreCase(classtype)) {

					PreparedStatement pst5 = null;
					pst5 = connection
							.prepareStatement(ICutomerQueryMapper.REDUCE_FIRST_SEATS);
					pst5.setString(1,
							flightInformationBean.getFlightNumber());
				

					for (int i = 1; i <= no_of_passengers; i++) {
						

						pst5.executeUpdate();

					}


				}

				/*******************************************************************************************************
				 * - Author : ARS Team - Creation Date : 14/12/2017 - Description :
				 ********************************************************************************************************/

				if ("bussclass".equalsIgnoreCase(classtype))

				{
					PreparedStatement pst6 = null;
					pst6 = connection
							.prepareStatement(ICutomerQueryMapper.REDUCE_BUSS_SEATS);
					pst6.setString(1,
							flightInformationBean.getFlightNumber());

					
					for (int i = 1; i <= no_of_passengers; i++) {

						pst6.executeUpdate();

					}
					
				}
				
				logger.info("booking details added successfully:");
				return bookingId;
			}
			else
			{
				logger.error("Insertion failed ");
				throw new ARSException("Inserting booking details failed ");

			}

			

		} catch (Exception e) {
			throw new ARSException("Customer Booking failed in BookingDao "
					+ e.getMessage());
		}
	}

	
	

	
	/*******************************************************************************************************
	 - Function Name	:	displayBooking()
	 - Input Parameters	:   bookingId
	 - Return Type		:	BookingInformationBean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	16/12/2017
	 - Description		:	Displaying booking Information
********************************************************************************************************/
	@Override
	public BookingInformationBean displayBooking(String bookingId)
			throws ARSException {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		BookingInformationBean bean = new BookingInformationBean();

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(ICutomerQueryMapper.DISPLAY_BOOKING);

			preparedStatement.setString(1, bookingId);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {

				bean.setBookingId(resultSet.getString("booking_id"));
				bean.setCustomerEmail(resultSet.getString("cust_email"));
				bean.setNumberOfPassengers(resultSet.getInt("no_of_passengers"));
				bean.setClassType(resultSet.getString("class_type"));
				
				bean.setTotalFare(resultSet.getDouble("total_fare"));
				bean.setSeatNumbers(resultSet.getString("seat_number"));
				bean.setCreditCardInformation(resultSet
						.getString("credit_card_info"));
				bean.setSourceCity(resultSet.getString("src_city"));
				bean.setDestinationCity(resultSet.getString("dest_city"));
				bean.setFlightNumber(resultSet.getString("flightno"));

				return bean;
			}

			// logger.info("Admin is authenticated.");

		} catch (Exception e) {
			throw new ARSException(
					"No booking details found in booking info dao "
							+ e.getMessage());
		}
		return null;
	}

	
	
	/*******************************************************************************************************
	 - Function Name	:	cancelBooking()
	 - Input Parameters	:   bookingId
	 - Return Type		:	boolean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	16/12/2017
	 - Description		:	Cancel a Ticket
********************************************************************************************************/
	
	@Override
	public boolean cancelBooking(String bookingId) throws ARSException {
		PreparedStatement preparedStatement = null;
		

		int records = 0;
		boolean isDeleted = false;
		
		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(ICutomerQueryMapper.CANCEL_BOOKING);

			preparedStatement.setString(1, bookingId);

			records = preparedStatement.executeUpdate();
			
	       
			
			if (records > 0)
				isDeleted = true;

		} catch (Exception e) {
			throw new ARSException(
					"cancellation of ticket failed in bookingdao "
							+ e.getMessage());
		}
		return isDeleted;
	}

	
	/*******************************************************************************************************
	 - Function Name	:	updateBooking()
	 - Input Parameters	:   bookingId,cust_email
	 - Return Type		:	boolean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	16/12/2017
	 - Description		:	update booking information
********************************************************************************************************/
	
	
	@Override
	public boolean updateBooking(
			String bookingId,String cust_email) throws ARSException {

		PreparedStatement preparedStatement = null;

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(ICutomerQueryMapper.UPDATE_BOOKING);

			preparedStatement.setString(1,cust_email);
			preparedStatement.setString(2,bookingId);

			int isUpdated = preparedStatement.executeUpdate();

			if (isUpdated > 0) {
				return true;
			}

		} catch (Exception e) {
			throw new ARSException("Booking Information updation failed "
					+ e.getMessage());
		}

		return false;
	}

	
	/*******************************************************************************************************
	 - Function Name	:	viewFlights()
	 - Input Parameters	:   source,destination
	 - Return Type		:	List of all flights
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	16/12/2017
	 - Description		:	view flight information between source and destination
********************************************************************************************************/

	
	@Override
	public List<FlightInformationBean> viewFlights(String Source,
			String destination) throws ARSException {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<FlightInformationBean> list = new ArrayList<FlightInformationBean>();

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(ICutomerQueryMapper.VIEW_FLIGHTS);

			preparedStatement.setString(1, Source);
			preparedStatement.setString(2, destination);

			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				FlightInformationBean bean = new FlightInformationBean();

				bean.setFlightNumber(resultSet.getString("flightno"));
				bean.setAirline(resultSet.getString("airline"));
				bean.setDepartureCity(resultSet.getString("dep_city"));
				bean.setArrivalCity(resultSet.getString("arr_city"));
				bean.setDepartureDate(resultSet.getDate("dep_date")
						.toLocalDate());
				bean.setArrivalDate(resultSet.getDate("arr_date").toLocalDate());
				bean.setDepartureTime(resultSet.getString("dep_time"));
				bean.setArrivalTime(resultSet.getString("arr_time"));
				bean.setFirstClassSeats(resultSet.getInt("FirstSeats"));
				bean.setFirstClassSeatFare(resultSet.getDouble("FirstSeatFare"));
				bean.setBussinessClassSeats(resultSet.getInt("BussSeats"));
				bean.setBussinessClassSeatsFare(resultSet
						.getDouble("BussSeatsFare"));

				list.add(bean);
			}

			// logger.info("Admin is authenticated.");

		} catch (Exception e) {
			throw new ARSException("No flight found exception "
					+ e.getMessage());
		}
		return list;
	}

	
	/*******************************************************************************************************
	 - Function Name	:	updateSeats()
	 - Input Parameters	:   FlightInformationBean,BookingInformationBean
	 - Return Type		:	boolean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	16/12/2017
	 - Description		:	update seats information
********************************************************************************************************/

	
	@Override
	public boolean updateSeats(FlightInformationBean flightInformationBean,
			BookingInformationBean bookingInformationBean) throws ARSException {
		
		PreparedStatement preparedStatement1 = null;
		
		String classType=bookingInformationBean.getClassType();
		System.out.println(classType);
		
		try {
			Connection connection = DBConnection.getInstance().getConnection();
			
			if ("firstclass".equalsIgnoreCase(classType)) {
				
				
				preparedStatement1 = connection
						.prepareStatement(ICutomerQueryMapper.INC_FIRST_SEATS);
				
				preparedStatement1.setString(1, flightInformationBean.getFlightNumber());

				for (int i = 1; i <= bookingInformationBean.getNumberOfPassengers(); i++) {
					
					
					preparedStatement1.executeUpdate();
					
					
				}
				
			} else if (bookingInformationBean.getClassType().equalsIgnoreCase("bussclass")) {

				preparedStatement1 = connection
						.prepareStatement(ICutomerQueryMapper.INC_BUSS_SEATS);

				preparedStatement1.setString(1, flightInformationBean.getFlightNumber());

				for (int i = 1; i <= bookingInformationBean.getNumberOfPassengers(); i++) {

					preparedStatement1.executeUpdate();
					
				}

			}
		} catch (SQLException e) {
			System.out.println("Seats Updation Failed"+e.getMessage());
			e.printStackTrace();
		}
		
		
		
		return false;
	}

}
