package com.cg.ars.pi;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.service.FlightInfoServiceImpl;
import com.cg.service.IFlightInfoService;
import com.cg.service.IUserService;
import com.cg.service.UserServiceImpl;

public class StaffARS {
	static Scanner ip = new Scanner(System.in);
	public static IUserService userService=new UserServiceImpl();
	public static IFlightInfoService flightService= new FlightInfoServiceImpl() ;
	
	public static void verifyUser()
	{	
		
		
		System.out.println("SELECT THE USER TYPE TO LOGIN : ");
		System.out.println("1. ADMIN LOGIN");
		System.out.println("2. EXECUTIVE LOGIN");
		Byte choice = Byte.parseByte(ip.next());
		
		
		if (choice==1) {
			
			ip.nextLine();
			System.out.println("Enter username");
			String username=ip.nextLine();
			System.out.println("Enter password");
			String password=ip.nextLine();
			boolean isValid=false;
			try {
				isValid = userService.isValidUser(username, password, "Admin");
			} catch (ARSException e) {
				System.out.println("Exception in admin login "+e.getMessage());
			}
			if(isValid)
			{
				System.out.println("Welcome "+username);
		
				viewAllFlights();
				viewParticularFlight();
			}
			else
			{
				System.out.println("Invalid user");
			}
			
		}
		
		
		
		
		
		
		
		
		else{
			ip.nextLine();
			System.out.println("Enter username");
			String username=ip.nextLine();
			System.out.println("Enter password");
			String password=ip.nextLine();
			boolean isValid=false;
			try {
				isValid = userService.isValidUser(username, password, "executive");
			} catch (ARSException e) {
				System.err.println("Exception in executive login "+e.getMessage());
			}
			if(isValid)
			{
				System.out.println("Welcome "+username);
				
			}
			else
			{
				System.out.println("Invalid user");
			}
		}
		
		ip.close();
		
	}
	
	public static void viewAllFlights()
	{	
		try {
			
			List<FlightInformationBean> list=flightService.viewAllFlightInformation();
			for (FlightInformationBean flightInformationBean : list) {
				
				System.out.println(flightInformationBean);
			}
		} catch (ARSException e) {
			System.err.println("Flight information error "+e.getMessage());
		}
	}
	public static void viewParticularFlight()
	{
		System.out.println("Enter Flight Number: ");
		String flightNumber= ip.nextLine();
		try {
			
			FlightInformationBean bean=flightService.viewParticularFlightInfo(flightNumber);
			
				System.out.println(bean);
		
		} catch (ARSException e) {
			System.err.println("Flight information error "+e.getMessage());
		}
	}
	
	public static void addFlight()
	{	FlightInformationBean fbean= new FlightInformationBean();
		
		System.out.println("Please enter flight information");
		
		System.out.println("Enter Flight Number");
		fbean.setFlightNumber(ip.nextLine());	
		System.out.println("Enter Flight Airline");
		fbean.setAirline(ip.nextLine());
		System.out.println("Enter Dep City");
		fbean.setDepartureCity(ip.nextLine());
		System.out.println("Enter Arr City");
		fbean.setArrivalCity(ip.nextLine());
		System.out.println("Enter Dep Date");
		String depdate = ip.nextLine();
		LocalDate depdate = LocalDate.parse("depdate");
		System.out.println("Enter Arr Date");
		
		System.out.println("Enter Dep Time");
		fbean.setDepartureTime(ip.nextLine());
		System.out.println("Enter Arr Time");
		fbean.setArrivalTime(ip.nextLine());
		System.out.println("Enter First Seats");
		fbean.setFirstClassSeats(ip.nextInt());
		System.out.println("Enter First Seat Fare");
		fbean.setFirstClassSeatFare(ip.nextDouble());
		System.out.println("Enter Business Seats");
		fbean.setBussinessClassSeats(ip.nextInt());
		System.out.println("Enter Business Seat Fare");
		fbean.setBussinessClassSeatsFare(ip.nextDouble());
		
		try {
			boolean isAdded=flightService.addFlight(fbean);
		} catch (ARSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
