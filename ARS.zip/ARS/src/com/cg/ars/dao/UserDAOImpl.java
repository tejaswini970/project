package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.cg.ars.bean.UserBean;
import com.cg.ars.exception.ARSException;
import com.cg.ars.util.DBConnection;

public class UserDAOImpl implements IUserDAO {

	@Override
	public boolean insertuser(UserBean userBean) throws ARSException {
		
		int records = 0;
		boolean isInserted = false;
		
		try(Connection connPurchaseDetails =DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
				connPurchaseDetails.prepareStatement(QueryMapper.INSERT_USER);
				){
				preparedStatement.setString(1, userBean.getUsername());
				preparedStatement.setString(2, userBean.getPassword());
				preparedStatement.setString(3, userBean.getRole());
				preparedStatement.setString(4, userBean.getMobile_no());
				
				records = preparedStatement.executeUpdate();
				if(records > 0){
					isInserted = true;
					System.out.println("Inserted Successfully");
				}
		}catch(SQLException sqlEx){
			throw new ARSException(sqlEx.getMessage());
		}
		
		return isInserted;
	}

}
