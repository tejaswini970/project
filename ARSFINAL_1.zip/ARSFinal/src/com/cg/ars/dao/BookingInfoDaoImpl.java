package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.ars.util.DBConnection;

public class BookingInfoDaoImpl implements IBookingInfoDao {

	@Override
	public String confirmBooking(BookingInformationBean bookingInformationBean,
			FlightInformationBean flightInformationBean) throws ARSException {
		PreparedStatement preparedStatement = null;

		ResultSet resultSet = null;
		String bookingId = null;
		String seats = null;
		double totalAmount=0;
		int no_of_passengers=0;
		no_of_passengers=bookingInformationBean.getNumberOfPassengers();

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(ICutomerQueryMapper.BOOKING_ID_SEQUENCE);

			resultSet = preparedStatement.executeQuery();
			bookingId = resultSet.getString("bookingId_sequence");

			if(bookingInformationBean.getClassType()=="firstclass")
			{
			preparedStatement = connection
					.prepareStatement(ICutomerQueryMapper.FIRST_CLASS_SEQUENCE);
			for (int i = 0; i < no_of_passengers; i++) {
				resultSet = preparedStatement.executeQuery();
				seats =seats+" , "+ resultSet.getString("seatNumbersFirstClass_sequence");
			}
			totalAmount=bookingInformationBean.getNumberOfPassengers()*flightInformationBean.getFirstClassSeatFare();
			}
			
			
			if(bookingInformationBean.getClassType()=="businessclass")
		
			{
				preparedStatement = connection
						.prepareStatement(ICutomerQueryMapper.BUSINESS_CLASS_SEQUENCE);
				for (int i = 0; i < no_of_passengers; i++) {
					resultSet = preparedStatement.executeQuery();
					seats = seats+" , "+resultSet
							.getString("seatNumbersBussClass_sequence");
				}
				totalAmount=bookingInformationBean.getNumberOfPassengers()*flightInformationBean.getBussinessClassSeatsFare();
			}
			
			preparedStatement = connection
					.prepareStatement(ICutomerQueryMapper.CONFIRM_BOOKING);

			
			
			preparedStatement.setString(1, bookingId);
			preparedStatement.setString(2,
					bookingInformationBean.getCustomerEmail());
			preparedStatement.setInt(3,
					bookingInformationBean.getNumberOfPassengers());
			preparedStatement.setString(4,
					bookingInformationBean.getClassType());
			preparedStatement.setDouble(5,totalAmount);
			preparedStatement.setString(6, seats);
			
			preparedStatement.setString(7,
					bookingInformationBean.getCreditCardInformation());
			preparedStatement.setString(8,
					bookingInformationBean.getSourceCity());
			preparedStatement.setString(9,
					bookingInformationBean.getDestinationCity());
			preparedStatement.setString(10,
					bookingInformationBean.getFlightNumber());

			int inserted = preparedStatement.executeUpdate();
			if (inserted > 0) {
				System.out.println("");
				bookingId = bookingInformationBean.getBookingId();
			}

			// logger.info("Admin is authenticated.");

		} catch (Exception e) {
			throw new ARSException("Customer Booking failed in BookingDao "
					+ e.getMessage());
		}
		return bookingId;
	}

	@Override
	public BookingInformationBean displayBooking(String bookingId)
			throws ARSException {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		BookingInformationBean bean = new BookingInformationBean();

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(ICutomerQueryMapper.DISPLAY_BOOKING);

			preparedStatement.setString(1, bookingId);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {

				bean.setBookingId(resultSet.getString("booking_id"));
				bean.setCustomerEmail(resultSet.getString("cust_email"));
				bean.setNumberOfPassengers(resultSet.getInt("no_of_passengers"));
				bean.setClassType(resultSet.getString("class_type"));
				;
				bean.setTotalFare(resultSet.getDouble("total_fare"));
				bean.setSeatNumbers(resultSet.getString("seat_number"));
				bean.setCreditCardInformation(resultSet
						.getString("credit_card_info"));
				bean.setSourceCity(resultSet.getString("src_city"));
				bean.setDestinationCity(resultSet.getString("dest_city"));
				bean.setFlightNumber(resultSet.getString("flightno"));

				return bean;
			}

			// logger.info("Admin is authenticated.");

		} catch (Exception e) {
			throw new ARSException(
					"No booking details found in booking info dao "
							+ e.getMessage());
		}
		return null;
	}

	@Override
	public boolean cancelBooking(String bookingId) throws ARSException {
		PreparedStatement preparedStatement = null;

		int records = 0;
		boolean isDeleted = false;

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(ICutomerQueryMapper.CANCEL_BOOKING);

			preparedStatement.setString(1, bookingId);

			records = preparedStatement.executeUpdate();

			if (records > 0)
				isDeleted = true;

		} catch (Exception e) {
			throw new ARSException(
					"cancellation of ticket failed in bookingdao "
							+ e.getMessage());
		}
		return isDeleted;
	}

	@Override
	public BookingInformationBean updateBooking(
			BookingInformationBean bookingInformationBean) throws ARSException {

		PreparedStatement preparedStatement = null;

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			preparedStatement = connection
					.prepareStatement(ICutomerQueryMapper.UPDATE_BOOKING);

			preparedStatement.setString(1,
					bookingInformationBean.getCustomerEmail());
			preparedStatement.setInt(2,
					bookingInformationBean.getNumberOfPassengers());
			preparedStatement.setString(3,
					bookingInformationBean.getClassType());
			preparedStatement.setDouble(4,
					bookingInformationBean.getTotalFare());
			preparedStatement.setString(5,
					bookingInformationBean.getSeatNumbers());
			preparedStatement.setString(6,
					bookingInformationBean.getCreditCardInformation());
			preparedStatement.setString(7,
					bookingInformationBean.getBookingId());

			int isUpdated = preparedStatement.executeUpdate();

			if (isUpdated > 0) {
				return bookingInformationBean;
			}

		} catch (Exception e) {
			throw new ARSException("Booking Information updation failed "
					+ e.getMessage());
		}

		return null;
	}

}
