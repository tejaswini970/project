package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.ars.exception.ARSException;
import com.cg.ars.util.DBConnection;

public class UserDAOImpl implements IUserDAO {

	
		
		
		

	@Override
	public String validuser(String userName,String password,String role,String mobileNo) throws ARSException {

		String user = null;
		try(Connection connPurchaseDetails =DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
				connPurchaseDetails.prepareStatement(QueryMapper.VALID_USER);
				){
				preparedStatement.setString(1, userName);
				preparedStatement.setString(2, password);
				preparedStatement.setString(3, role);
				preparedStatement.setLong(4, Long.parseLong(mobileNo));
				
				ResultSet resultset=preparedStatement.executeQuery();
				while (resultset.next()) {
					
				user=resultset.getString(1);
					
				}
			
		}catch(SQLException sqlEx){
			throw new ARSException(sqlEx.getMessage());
		}
		
		return user;
	}
	}


