package com.cg.ars.dao;

import com.cg.ars.bean.UserBean;
import com.cg.ars.exception.ARSException;



public interface IUserDAO {
	public boolean insertuser(UserBean userBean) throws ARSException;
	
}
