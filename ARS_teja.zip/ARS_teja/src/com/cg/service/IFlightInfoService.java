/**
 * 
 */
package com.cg.service;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;


/**
 * @author CAPG
 *
 */
public interface IFlightInfoService {

	public FlightInformationBean getAirplaneInfo(FlightInformationBean flightInformationBean)throws ARSException;

	public FlightInformationBean fetchFlight(FlightInformationBean flightInformationBean)throws ARSException;

	public FlightInformationBean addFlight()throws ARSException;

	public FlightInformationBean deleteFlight(String flightNo)throws ARSException;

	public FlightInformationBean updateFlight(String flightNo)throws ARSException;
}
