package com.cg.service;

import com.cg.ars.bean.UserBean;
import com.cg.ars.exception.ARSException;

public class UserServiceImpl implements IUserService {

	@Override
	public UserBean getAuthentication(UserBean usersBean) throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserBean createUser(UserBean usersBean) throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}

}
