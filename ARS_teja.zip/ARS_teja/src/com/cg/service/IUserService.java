/**
 * 
 */
package com.cg.service;

import com.cg.ars.bean.UserBean;
import com.cg.ars.exception.ARSException;



/**
 * @author CAPG
 *
 */
public interface IUserService {

	public UserBean getAuthentication(UserBean usersBean)throws ARSException;

	public UserBean createUser(UserBean usersBean)throws ARSException;

}
